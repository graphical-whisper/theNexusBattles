
# FastAPI IA Server for Nexus Battles — clean build
# - Optional Keras policy (.keras or .h5) if present in ./models
# - Safe rule-based fallback if model is absent
# - Single, stable endpoint: POST /v1/decide
# - Health: GET /health
import os
from typing import List, Literal, Optional, Tuple

import numpy as np
from fastapi import FastAPI
from pydantic import BaseModel, Field

# ============ Optional ML policy (lazy import to avoid heavy deps when unused) ============
def _try_load_model():
    model_dir = os.path.join(os.path.dirname(__file__), "..", "models")
    for fname in ("hero_action_selector.keras", "hero_action_selector.h5"):
        fpath = os.path.join(model_dir, fname)
        if os.path.exists(fpath):
            try:
                from tensorflow import keras  # lazy import
                return keras.models.load_model(fpath)
            except Exception as e:
                print(f"[warn] Could not load model {fpath}: {e}")
    return None

# ============ Domain ============
ActionKind = Literal["basic", "attack", "special1", "special2", "special3"]

class BattleSide(BaseModel):
    hero_type: str = Field(..., description="e.g., 'rogue', 'mage', 'warrior'")
    hp: float = Field(..., ge=0.0)
    mp: float = Field(0.0, ge=0.0)
    level: int = Field(1, ge=1, le=99)
    cooldowns: dict = Field(default_factory=dict, description="e.g., {'special1': 0, 'special2': 2}")
    buffs: dict = Field(default_factory=dict)
    debuffs: dict = Field(default_factory=dict)

class DecideRequest(BaseModel):
    actor: BattleSide
    enemy: BattleSide
    turn: int = Field(1, ge=1)
    rng: Optional[int] = Field(None, description="Optional RNG seed to make decisions reproducible")

class DecideResponse(BaseModel):
    action: ActionKind
    reason: str
    confidence: float = Field(0.5, ge=0.0, le=1.0)

# ============ Heuristics and specials availability per hero ============
HERO_SPECIALS = {
    "rogue":   ["special1", "special2", "special3"],
    "mage":    ["special1", "special2", "special3"],
    "warrior": ["special1", "special2", "special3"],
}

def _is_available(actor: BattleSide, act: ActionKind) -> bool:
    if not act.startswith("special"):
        return True
    cd = int(actor.cooldowns.get(act, 0))
    cost = 10 if act == "special1" else 15 if act == "special2" else 20
    return cd <= 0 and actor.mp >= cost

def _rule_based_policy(actor: BattleSide, enemy: BattleSide) -> Tuple[ActionKind, str, float]:
    # Simple, sane rules:
    # - If enemy HP is low, finish with 'attack'
    if enemy.hp <= max(10.0, 0.15 * 100):  # using a nominal 100 scale if unknown
        return "attack", "Enemy HP low → finish with attack", 0.65
    # - Prefer highest available special if actor has MP and not on cooldown
    for act in ("special3", "special2", "special1"):
        if _is_available(actor, act): 
            return act, f"{act} available and MP sufficient", 0.7
    # - Fallback
    return "basic", "No specials available → basic attack", 0.55

def _featurize(actor: BattleSide, enemy: BattleSide) -> np.ndarray:
    # Minimal numeric vector (extend to match your trained model!)
    hero_map = {"rogue": 0, "mage": 1, "warrior": 2}
    a_type = hero_map.get(actor.hero_type, 3)
    e_type = hero_map.get(enemy.hero_type, 3)
    vec = np.array([
        a_type, actor.hp, actor.mp, actor.level,
        e_type, enemy.hp, enemy.mp, enemy.level,
        int(actor.cooldowns.get("special1", 0)),
        int(actor.cooldowns.get("special2", 0)),
        int(actor.cooldowns.get("special3", 0)),
    ], dtype=np.float32)
    return vec[None, :]

# ============ App ============
app = FastAPI(title="NexusBattle IA Server", version="2.0.0")

_model = None  # lazy

@app.on_event("startup")
def _maybe_load_model():
    global _model
    _model = _try_load_model()
    if _model is None:
        print("[info] No model found. Running in rule-based mode.")
    else:
        print("[info] ML model loaded. Running in ML mode.")

@app.get("/health")
def health():
    return {
        "ok": True,
        "mode": "ml" if _model is not None else "rules",
        "expected_model_paths": ["./models/hero_action_selector.keras", "./models/hero_action_selector.h5"],
        "supported_actions": ["basic", "attack", "special1", "special2", "special3"],
        "heroes_with_specials": list(HERO_SPECIALS.keys()),
    }

@app.post("/v1/decide", response_model=DecideResponse)
def decide(req: DecideRequest) -> DecideResponse:
    if req.rng is not None:
        np.random.seed(req.rng)
    # Try ML first if present
    if _model is not None:
        try:
            x = _featurize(req.actor, req.enemy)
            logits = _model.predict(x, verbose=0)[0]
            acts = ["basic", "attack", "special1", "special2", "special3"]
            idx = int(np.argmax(logits))
            chosen = acts[idx] if 0 <= idx < len(acts) else "basic"
            # Validate availability; if not available, fall back to rules
            if chosen.startswith("special") and not _is_available(req.actor, chosen):  # noqa
                act, reason, conf = _rule_based_policy(req.actor, req.enemy)
                return DecideResponse(action=act, reason=f"ML chose unavailable action. Fallback → {reason}", confidence=conf)
            conf = float(np.max(np.exp(logits) / np.sum(np.exp(logits))))
            return DecideResponse(action=chosen, reason="Chosen by ML policy", confidence=conf)
        except Exception as e:
            # Fall back robustly
            act, reason, conf = _rule_based_policy(req.actor, req.enemy)
            return DecideResponse(action=act, reason=f"ML error → {e}. Fallback → {reason}", confidence=conf)
    # Rule-based
    act, reason, conf = _rule_based_policy(req.actor, req.enemy)
    return DecideResponse(action=act, reason=reason, confidence=conf)

# Entrypoint for local dev: `python -m app.server`
if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app.server:app", host="0.0.0.0", port=8000, reload=False)
